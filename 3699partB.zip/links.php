<div class="link-container flex-column thin-border">
    <a class="link lavender mb" href="home_page.php">Αρχική Σελίδα</a>
    <a class="link lavender mb" href="announcements.php">Ανακοινώσεις</a>
    <a class="link lavender mb" href="communication.php">Επικοινωνία</a>
    <a class="link lavender mb" href="documents.php">Έγγραφα Μαθήματος</a>
    <a class="link lavender mb" href="homework.php">Εργασίες</a>
</div>